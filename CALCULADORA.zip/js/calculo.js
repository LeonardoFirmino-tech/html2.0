var n1 = document.querySelector('#n1')
   var n2 = document.querySelector('#n2')
   var resultado = document.querySelector('#resultado')
   var calc = 0.15
   function somar() {
    resultado.innerHTML = Number(n1.value) + Number(n2.value)
   }
   function subtrair() {
    resultado.innerHTML = Number(n1.value) - Number(n2.value)
   }
   function multiplicar() {
     resultado.innerHTML = Number(n1.value) * Number(n2.value)
   }
   function divisão() {
    if (Number(n2.value) ===0) {
        resultado.innerHTML = 'erro de divisão por zero';
    } else {
        resultado.innerHTML = Number(n1.value) / Number(n2.value);
    }
   }
   function porcentagem(){
    if (Number(n1.value)>=1000)
    resultado.innerHTML = Number(n1.value) - Number(n1.value) * 0.10
   }
   function porcentagem2(){
    resultado.innerHTML = Number(n1.value) + Number(n2.value) * calc
   }
   function porcentagem3(){}
   function porcentagem4(){}
   function porcentagem5(){}