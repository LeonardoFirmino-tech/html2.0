var n1 = document.querySelector('#n1')
   var n2 = document.querySelector('#n2')
   var resultado = document.querySelector('#resultado')
   function somar() {
    resultado.innerHTML = Number(n1.value) + Number(n2.value)
   }
   function subtrair() {
    resultado.innerHTML = Number(n1.value) - Number(n2.value)
   }
   function multiplicar() {
     resultado.innerHTML = Number(n1.value) * Number(n2.value)
   }
   function divisão() {
    if (Number(n2.value) ===0) {
        resultado.innerHTML = 'erro de divisão por zero';
    } else {
        resultado.innerHTML = Number(n1.value) / Number(n2.value);
    }
   }
   function porcentagem(){
    resultado.innerHTML = Number(n1.value) - Number(n1.value) * 0.10
   }
   function lucro15(){
    resultado.innerHTML = Number(n1.value+n2.value) + Number(n1.value+n2.value) * 0.15
   }
   function desconto3(){
    resultado.innerHTML = Number(n1.value+n2.value) - Number(n1.value+n2.value) * 0.03
   }
   function maior1000(){
    if (Number(n1.value) >= 1000)  
        { resultado.innerHTML = Number(n1.value+n2.value) - Number(n1.value+n2.value) * 0.07} 
   }
   function lucro5(){
    if (Number(n1.value) <= 500)
     resultado.innerHTML = Number(n1.value) + Number(n2.value) + Number(n1.value+n2.value) * 0.05
   }
   function boacompra(){
    if (Number(n1.value) <=200) 
        resultado.innerHTML = "BOA COMPRA"
}